<?php
session_start();
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Database connection
    $servername = "localhost";
    $username = "root";  // Replace with your DB username
    $password = "";      // Replace with your DB password
    $dbname = "farmer_db";  // Replace with your DB name

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check for connection errors
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $farmer_username = $_POST['username'];
    $farmer_password = $_POST['password'];

    // Prepare SQL query to check for the farmer
    $sql = "SELECT * FROM farmers WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $farmer_username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        
        // Verify the password
        if (password_verify($farmer_password, $row['password'])) {
            $_SESSION['farmer_id'] = $row['id'];
            $_SESSION['username'] = $row['username'];
            header("Location: dashboard.php");  // Redirect to dashboard
            exit();
        } else {
            echo "अयोग्य पासवर्ड!";
        }
    } else {
        echo "वापरकर्ता नाव अस्तित्वात नाही!";
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="mr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>किसान लॉगिन</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: url('farm-background.jpg') no-repeat center center fixed;
            background-size: cover;
            color: #fff;
            text-align: center;
            padding: 50px;
        }
        h1 {
            color: #f8f8f8;
            font-size: 36px;
            text-shadow: 2px 2px 5px rgba(0, 0, 0, 0.5);
        }
        .login-container {
            background-color: rgba(255, 255, 255, 0.8);
            padding: 40px;
            width: 40%;
            margin: 0 auto;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
        }
        input {
            padding: 10px;
            width: 100%;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            background-color: #28a745;
            color: white;
            padding: 10px 20px;
            width: 100%;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h1>किसान लॉगिन</h1>
        <form action="farmer_login.php" method="POST">
            <input type="text" name="username" placeholder="वापरकर्ता नाव" required>
            <input type="password" name="password" placeholder="पासवर्ड" required>
            <button type="submit">लॉगिन करा</button>
        </form>
        <p>नवीन आहात? <a href="register_farmer.php">नोंदणी करा</a></p>
    </div>
</body>
</html>
