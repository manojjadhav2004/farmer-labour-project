<?php
include 'db.php';

// Fetch labor data from the database
$stmt = $pdo->query("SELECT * FROM labor");
$labors = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="mr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>मजुरांची यादी</title>
    <style>
        /* General Styles */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f0f0f5;
            color: #333;
            margin: 0;
            padding: 0;
            text-align: center;
        }

        header {
            background-color: #4CAF50; /* Green */
            padding: 20px;
            margin-bottom: 30px;
            color: white;
            position: relative;
        }

        header h1 {
            margin: 0;
            font-size: 28px;
        }

        .logo {
            position: absolute;
            top: 10px;
            right: 20px;
            height: 40px;
        }

        /* Table Styles */
        .table-container {
            width: 80%;
            margin: 0 auto;
            overflow-x: auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 12px 15px;
            text-align: center;
            font-size: 16px;
        }

        th {
            background-color: #4CAF50;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        /* Back Link */
        .back-link {
            margin: 20px 0;
        }

        .back-link a {
            text-decoration: none;
            color: #4CAF50;
            font-size: 18px;
            padding: 10px 20px;
            border: 2px solid #4CAF50;
            border-radius: 5px;
            transition: all 0.3s ease;
        }

        .back-link a:hover {
            background-color: #4CAF50;
            color: white;
        }
    </style>
</head>
<body>
    <header>
        <h1>उपलब्ध मजुरांची यादी</h1>
        
    </header>

    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>नाव</th>
                    <th>भाग</th>
                    <th>कामाचा प्रकार</th>
                    <th>मोबाईल नंबर</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($labors as $labor): ?>
                <tr>
                    <td><?= htmlspecialchars($labor['name']) ?></td>
                    <td><?= htmlspecialchars($labor['location']) ?></td>
                    <td><?= htmlspecialchars($labor['work_type']) ?></td>
                    <td><?= htmlspecialchars($labor['contact_number']) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div class="back-link">
        <a href="index.php">मुख्य पृष्ठावर परत जा</a>
    </div>
</body>
</html>
