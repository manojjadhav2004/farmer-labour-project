CREATE TABLE labor (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    location VARCHAR(100) NOT NULL,
    work_type VARCHAR(100) NOT NULL,
    contact_number VARCHAR(15) NOT NULL
);
