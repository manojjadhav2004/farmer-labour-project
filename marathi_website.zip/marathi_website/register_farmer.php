<?php
// Database connection
$servername = "localhost";
$username = "root";  // Your DB username
$password = "";      // Your DB password
$dbname = "farmer_db";  // Your database name

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get farmer's registration data
    $farmer_username = $_POST['username'];
    $farmer_password = $_POST['password'];
    $farmer_name = $_POST['name'];
    $farmer_email = $_POST['email'];

    // Hash the password before saving it
    $hashed_password = password_hash($farmer_password, PASSWORD_DEFAULT);

    // Check if the username already exists
    $sql = "SELECT * FROM farmers WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $farmer_username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo "ह्या वापरकर्त्या नावाने आधीच खाते अस्तित्वात आहे!";
    } else {
        // Insert new farmer into the database
        $sql = "INSERT INTO farmers (username, password, name, email) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssss", $farmer_username, $hashed_password, $farmer_name, $farmer_email);

        if ($stmt->execute()) {
            echo "आपले खाते यशस्वीरित्या तयार झाले आहे! <a href='farmer_login.php'>लॉगिन करा</a>";
        } else {
            echo "त्रुटी आली आहे. कृपया पुन्हा प्रयत्न करा.";
        }
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="mr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>किसान नोंदणी</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: url('farm-background.jpg') no-repeat center center fixed;
            background-size: cover;
            color: #fff;
            text-align: center;
            padding: 50px;
        }
        h1 {
            color: #f8f8f8;
            font-size: 36px;
            text-shadow: 2px 2px 5px rgba(0, 0, 0, 0.5);
        }
        .registration-container {
            background-color: rgba(255, 255, 255, 0.8);
            padding: 40px;
            width: 40%;
            margin: 0 auto;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
        }
        input {
            padding: 10px;
            width: 100%;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            background-color: #28a745;
            color: white;
            padding: 10px 20px;
            width: 100%;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>
    <div class="registration-container">
        <h1>किसान नोंदणी</h1>
        <form action="register_farmer.php" method="POST">
            <input type="text" name="username" placeholder="वापरकर्ता नाव" required>
            <input type="password" name="password" placeholder="पासवर्ड" required>
            <input type="text" name="name" placeholder="तुमचं नाव" required>
            <input type="email" name="email" placeholder="ईमेल आयडी" required>
            <button type="submit">नोंदणी करा</button>
        </form>
        <p>आधीच खाते आहे? <a href="farmer_login.php">लॉगिन करा</a></p>
    </div>
</body>
</html>
