<!DOCTYPE html>
<html lang="mr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>शेती कामासाठी मजुरांची माहिती</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: url('farm-background.jpg') no-repeat center center fixed;
            background-size: cover;
            color: #fff;
            text-align: center;
            padding: 50px;
        }
        h1 {
            color: #f8f8f8;
            font-size: 36px;
            text-shadow: 2px 2px 5px rgba(0, 0, 0, 0.5);
        }
        .content {
            margin: 20px auto;
            width: 60%;
            padding: 30px;
            background-color: rgba(255, 255, 255, 0.8);
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.3);
            border-radius: 10px;
        }
        p {
            font-size: 18px;
            color: #333;
        }
        a {
            display: inline-block;
            margin: 15px;
            padding: 15px 30px;
            background-color: #28a745;
            color: #fff;
            text-decoration: none;
            font-size: 18px;
            border-radius: 50px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
            transition: background-color 0.3s ease;
            position: relative;
        }
        a:hover {
            background-color: #218838;
        }
        a img {
            width: 30px;
            height: 30px;
            position: absolute;
            left: -40px;
            top: 50%;
            transform: translateY(-50%);
        }
        .btn1 {
            background-color: #007bff;
        }
        .btn1:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="content">
        <h1>शेती कामासाठी मजुरांची माहिती</h1>
        <p>महाराष्ट्रातील शेतकऱ्यांना त्यांच्या भागातील उपलब्ध मजुरांची माहिती मिळवण्यासाठी ही वेबसाइट उपयुक्त आहे.</p>
        <a href="majur.php" class="btn1">मजुरांची यादी पहा</a>
        <a href="add_labor.php">नवीन मजूर जोडा</a>
        <!-- Add a Farmer Login link -->
        <a href="farmer_login.php" class="btn1">किसान लॉगिन</a>
    </div>
</body>
</html>
