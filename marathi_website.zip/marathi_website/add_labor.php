<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $location = $_POST['location'];
    $work_type = $_POST['work_type'];
    $contact_number = $_POST['contact_number'];

    // Insert data into the database
    $stmt = $pdo->prepare("INSERT INTO labor (name, location, work_type, contact_number) VALUES (?, ?, ?, ?)");
    $stmt->execute([$name, $location, $work_type, $contact_number]);

    echo "<p>मजूर माहिती यशस्वीरित्या समाविष्ट झाली आहे.</p>";
}
?>

<!DOCTYPE html>
<html lang="mr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>मजूर माहिती जोडा</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-image: url('background.jpg'); /* Add your background image here */
            background-size: cover;
            background-position: center;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 400px;
            margin: 50px auto;
            background-color: rgba(255, 255, 255, 0.9); /* Semi-transparent white */
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #4CAF50; /* Green */
            font-size: 24px;
            margin-bottom: 20px;
        }

        form input[type="text"], form input[type="submit"] {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border-radius: 5px;
            border: 1px solid #ccc;
            font-size: 16px;
        }

        form input[type="submit"] {
            background-color: #4CAF50; /* Green */
            color: white;
            border: none;
            cursor: pointer;
        }

        form input[type="submit"]:hover {
            background-color: #45a049; /* Darker Green */
        }

        p {
            text-align: center;
            font-size: 18px;
            color: #333;
        }

        a {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: #333;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>मजूर माहिती जोडा</h1>
        <form method="POST" action="">
            नाव: <input type="text" name="name" required><br>
            भाग: <input type="text" name="location" required><br>
            कामाचा प्रकार: <input type="text" name="work_type" required><br>
            मोबाईल नंबर: <input type="text" name="contact_number" required><br>
            <input type="submit" value="समाविष्ट करा">
        </form>
        <a href="index.php">मुख्य पृष्ठावर परत जा</a>
    </div>
</body>
</html>
